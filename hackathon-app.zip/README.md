# Hackathon Leader Onboarding Web App

A simple web application for hackathon leader registration and management using HTML, CSS, JavaScript, and Supabase.

## Live Demo

[View Live Demo](#) (Add your deployed URL here)

## Features

### User Roles

1. **Leader** (default role after signup)
   - Signs up with email + password (Supabase Auth with email verification)
   - Automatically redirected to Team Registration Form after verification
   - Can view/edit their team details later
   - Dashboard contains:
     - Registered Team Details
     - Announcements (from Admin)
     - Resources (links from Admin)

2. **Admin**
   - Logs in with email + password (separate role)
   - Can create/manage Announcements & Resources
   - Can view all registered teams

### Key Features

- **Authentication**: Email + Password signup/login with Supabase Auth and email verification
- **Team Registration Form**: Collects team details including members
- **Leader Dashboard**: Team details, announcements, and resources
- **Admin Dashboard**: Manage announcements, resources, and view all teams
- **Responsive UI**: Clean, responsive design with dashboard navigation

## Tech Stack

- **Frontend**: HTML + CSS + Vanilla JavaScript
- **Backend**: Supabase (Auth, Database, RLS policies)
- **Hosting**: Vercel/Netlify (static frontend) + Supabase backend

## Setup Instructions

1. Clone the repository
2. Update the Supabase configuration in all JavaScript files:
   ```javascript
   const SUPABASE_URL = 'YOUR_SUPABASE_URL';
   const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
   ```
3. Deploy the frontend to Vercel/Netlify
4. Set up Supabase backend with required tables and RLS policies

## Project Structure

```
.
├── index.html (redirects to landing.html)
├── landing.html
├── 404.html
├── team-registration.html
├── dashboard.html
├── admin.html
├── styles/
│   └── main.css
├── scripts/
│   ├── main.js
│   ├── team-registration.js
│   ├── dashboard.js
│   └── admin.js
└── README.md
```

## Supabase Setup

You'll need to create the following tables in your Supabase database:

1. **teams** - Stores team registration information
2. **announcements** - Stores announcements from admins
3. **resources** - Stores resource links from admins

### Example Table Structures

**teams table:**
```sql
CREATE TABLE teams (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  team_name VARCHAR UNIQUE NOT NULL,
  leader_name VARCHAR NOT NULL,
  leader_id UUID REFERENCES auth.users(id),
  stream VARCHAR NOT NULL,
  semester VARCHAR NOT NULL,
  category VARCHAR NOT NULL,
  members JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);
```

**announcements table:**
```sql
CREATE TABLE announcements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);
```

**resources table:**
```sql
CREATE TABLE resources (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR NOT NULL,
  link VARCHAR NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);
```

## Development

Simply open `landing.html` in a browser to run the application locally.

## Deployment

1. Frontend: Deploy to Vercel or Netlify
2. Backend: Configure Supabase project and database tables

## Contributing

This project was created for a hackathon and demonstrates a simple but complete web application with user authentication and role-based access control.