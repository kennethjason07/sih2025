// Supabase configuration
const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';

// Initialize Supabase
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// DOM Elements
const logoutBtn = document.getElementById('logoutBtn');

// Initialize the admin dashboard
document.addEventListener('DOMContentLoaded', async () => {
    // Check if user is logged in
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
        // Redirect to login if not authenticated
        window.location.href = 'index.html';
        return;
    }
    
    // Simple check for admin (in a real app, you would check user role in database)
    if (user.email !== 'admin@example.com') {
        alert('Access denied. Admin access required.');
        window.location.href = 'index.html';
        return;
    }
    
    // Add event listeners
    document.querySelectorAll('.sidebar-nav a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
            e.target.classList.add('active');
            const view = e.target.getAttribute('data-view');
            loadAdminView(view);
        });
    });
    
    logoutBtn.addEventListener('click', handleLogout);
    
    // Load default view
    loadAdminView('teams');
});

async function loadAdminView(view) {
    const content = document.getElementById('dashboard-content');
    
    switch(view) {
        case 'teams':
            content.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <h3>All Registered Teams</h3>
                    </div>
                    <div id="teamsList">
                        <p>Loading teams...</p>
                    </div>
                </div>
            `;
            loadAllTeams();
            break;
            
        case 'announcements':
            content.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <h3>Manage Announcements</h3>
                    </div>
                    <form id="announcementForm">
                        <div class="form-group">
                            <label for="announcementTitle">Title</label>
                            <input type="text" id="announcementTitle" required>
                        </div>
                        <div class="form-group">
                            <label for="announcementContent">Content</label>
                            <textarea id="announcementContent" rows="4" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-success">Add Announcement</button>
                    </form>
                    <div id="announcementsList">
                        <h4>Existing Announcements</h4>
                        <p>Loading announcements...</p>
                    </div>
                </div>
            `;
            document.getElementById('announcementForm').addEventListener('submit', addAnnouncement);
            loadAdminAnnouncements();
            break;
            
        case 'resources':
            content.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <h3>Manage Resources</h3>
                    </div>
                    <form id="resourceForm">
                        <div class="form-group">
                            <label for="resourceTitle">Title</label>
                            <input type="text" id="resourceTitle" required>
                        </div>
                        <div class="form-group">
                            <label for="resourceLink">Link</label>
                            <input type="url" id="resourceLink" required>
                        </div>
                        <button type="submit" class="btn btn-success">Add Resource</button>
                    </form>
                    <div id="resourcesList">
                        <h4>Existing Resources</h4>
                        <p>Loading resources...</p>
                    </div>
                </div>
            `;
            document.getElementById('resourceForm').addEventListener('submit', addResource);
            loadAdminResources();
            break;
    }
}

async function loadAllTeams() {
    // In a real app, you would fetch from Supabase
    const teamsList = document.getElementById('teamsList');
    teamsList.innerHTML = `
        <div class="list-item">
            <h4>Innovators Team</h4>
            <p>Leader: John Doe (john@example.com)</p>
            <p>Stream: Computer Science, Semester: 4, Category: GM</p>
            <p>Members: Jane Smith (jane@example.com), Bob Johnson (bob@example.com)</p>
        </div>
        <div class="list-item">
            <h4>Code Masters</h4>
            <p>Leader: Alice Brown (alice@example.com)</p>
            <p>Stream: Information Technology, Semester: 6, Category: OBC</p>
            <p>Members: Charlie Wilson (charlie@example.com), Diana Lee (diana@example.com)</p>
        </div>
        <div class="list-item">
            <h4>Data Wizards</h4>
            <p>Leader: Sam Wilson (sam@example.com)</p>
            <p>Stream: Data Science, Semester: 5, Category: SC</p>
            <p>Members: Emma Davis (emma@example.com), Frank Miller (frank@example.com)</p>
        </div>
    `;
}

async function addAnnouncement(e) {
    e.preventDefault();
    
    const title = document.getElementById('announcementTitle').value;
    const content = document.getElementById('announcementContent').value;
    
    // In a real app, you would save to Supabase
    console.log({ title, content });
    
    alert('Announcement added successfully!');
    document.getElementById('announcementForm').reset();
    
    // Refresh the announcements list
    loadAdminAnnouncements();
}

async function addResource(e) {
    e.preventDefault();
    
    const title = document.getElementById('resourceTitle').value;
    const link = document.getElementById('resourceLink').value;
    
    // In a real app, you would save to Supabase
    console.log({ title, link });
    
    alert('Resource added successfully!');
    document.getElementById('resourceForm').reset();
    
    // Refresh the resources list
    loadAdminResources();
}

async function loadAdminAnnouncements() {
    // In a real app, you would fetch from Supabase
    const announcementsList = document.getElementById('announcementsList');
    announcementsList.innerHTML = `
        <div class="list-item">
            <h4>Welcome to the Hackathon!</h4>
            <p>We're excited to have you participate in this year's hackathon. Please make sure to complete your team registration.</p>
            <small>Posted on: September 15, 2025</small>
            <button class="btn btn-danger" style="margin-top: 10px;">Delete</button>
        </div>
        <div class="list-item">
            <h4>Important Dates</h4>
            <p>Registration closes on October 1st. The hackathon begins on October 15th.</p>
            <small>Posted on: September 10, 2025</small>
            <button class="btn btn-danger" style="margin-top: 10px;">Delete</button>
        </div>
    `;
    
    // Add event listeners to delete buttons
    document.querySelectorAll('#announcementsList .btn-danger').forEach((button, index) => {
        button.addEventListener('click', function() {
            deleteAnnouncement(index);
        });
    });
}

async function loadAdminResources() {
    // In a real app, you would fetch from Supabase
    const resourcesList = document.getElementById('resourcesList');
    resourcesList.innerHTML = `
        <div class="list-item">
            <h4>Hackathon Guidelines</h4>
            <p><a href="https://example.com/guidelines" class="resource-link" target="_blank">https://example.com/guidelines</a></p>
            <button class="btn btn-danger" style="margin-top: 10px;">Delete</button>
        </div>
        <div class="list-item">
            <h4>API Documentation</h4>
            <p><a href="https://api.example.com/docs" class="resource-link" target="_blank">https://api.example.com/docs</a></p>
            <button class="btn btn-danger" style="margin-top: 10px;">Delete</button>
        </div>
    `;
    
    // Add event listeners to delete buttons
    document.querySelectorAll('#resourcesList .btn-danger').forEach((button, index) => {
        button.addEventListener('click', function() {
            deleteResource(index);
        });
    });
}

async function deleteAnnouncement(index) {
    // In a real app, you would delete from Supabase
    console.log('Deleting announcement:', index);
    alert('Announcement deleted successfully!');
    loadAdminAnnouncements();
}

async function deleteResource(index) {
    // In a real app, you would delete from Supabase
    console.log('Deleting resource:', index);
    alert('Resource deleted successfully!');
    loadAdminResources();
}

async function handleLogout() {
    await supabase.auth.signOut();
    window.location.href = 'index.html';
}