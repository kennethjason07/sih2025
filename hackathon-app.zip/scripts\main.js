// Supabase configuration
const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';

// Initialize Supabase
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// DOM Elements
const app = document.getElementById('app');

// State
let currentUser = null;
let userRole = 'leader'; // default role

// Initialize the app
document.addEventListener('DOMContentLoaded', async () => {
    // Check if user is already logged in
    const { data: { user } } = await supabase.auth.getUser();
    
    if (user) {
        currentUser = user;
        // Check if user is admin
        if (user.email === 'admin@example.com') { // Simple check for demo
            window.location.href = 'admin.html';
        } else {
            window.location.href = 'dashboard.html';
        }
    } else {
        showAuthForm();
    }
});

// Authentication Functions
function showAuthForm() {
    app.innerHTML = `
        <div class="auth-container">
            <h2>Login to Hackathon Portal</h2>
            <form id="authForm">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" required>
                </div>
                <button type="submit" class="btn">Login</button>
                <p>Don't have an account? <a href="#" id="showSignup">Sign Up</a></p>
            </form>
        </div>
    `;
    
    document.getElementById('authForm').addEventListener('submit', handleLogin);
    document.getElementById('showSignup').addEventListener('click', showSignupForm);
}

function showSignupForm() {
    app.innerHTML = `
        <div class="auth-container">
            <h2>Sign Up for Hackathon</h2>
            <form id="signupForm">
                <div class="form-group">
                    <label for="signupEmail">Email</label>
                    <input type="email" id="signupEmail" required>
                </div>
                <div class="form-group">
                    <label for="signupPassword">Password</label>
                    <input type="password" id="signupPassword" required>
                </div>
                <button type="submit" class="btn">Sign Up</button>
                <p>Already have an account? <a href="#" id="showLogin">Login</a></p>
            </form>
        </div>
    `;
    
    document.getElementById('signupForm').addEventListener('submit', handleSignup);
    document.getElementById('showLogin').addEventListener('click', showAuthForm);
}

async function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
    });
    
    if (error) {
        alert('Login failed: ' + error.message);
        return;
    }
    
    currentUser = data.user;
    
    // Redirect based on user role
    if (email === 'admin@example.com') {
        window.location.href = 'admin.html';
    } else {
        // Check if team is registered, if not redirect to team registration
        // For demo, we'll redirect to dashboard
        window.location.href = 'dashboard.html';
    }
}

async function handleSignup(e) {
    e.preventDefault();
    
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    
    const { data, error } = await supabase.auth.signUp({
        email,
        password
    });
    
    if (error) {
        alert('Signup failed: ' + error.message);
        return;
    }
    
    if (data.user) {
        alert('Signup successful! Please check your email for verification.');
        showAuthForm();
    }
}

async function handleLogout() {
    await supabase.auth.signOut();
    currentUser = null;
    userRole = 'leader';
    window.location.href = 'index.html';
}
