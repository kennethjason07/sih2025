// Supabase configuration
const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';

// Initialize Supabase
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// DOM Elements
const userEmailSpan = document.getElementById('userEmail');
const logoutBtn = document.getElementById('logoutBtn');

// State
let currentUser = null;

// Initialize the dashboard
document.addEventListener('DOMContentLoaded', async () => {
    // Check if user is logged in
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
        // Redirect to login if not authenticated
        window.location.href = 'index.html';
        return;
    }
    
    currentUser = user;
    userEmailSpan.textContent = user.email;
    
    // Add event listeners
    document.querySelectorAll('.sidebar-nav a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            document.querySelectorAll('.sidebar-nav a').forEach(a => a.classList.remove('active'));
            e.target.classList.add('active');
            const view = e.target.getAttribute('data-view');
            loadView(view);
        });
    });
    
    logoutBtn.addEventListener('click', handleLogout);
    
    // Load default view
    loadView('team');
});

async function loadView(view) {
    const content = document.getElementById('dashboard-content');
    
    switch(view) {
        case 'team':
            content.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <h3>Your Team Details</h3>
                    </div>
                    <div id="teamDetails">
                        <p>Loading team details...</p>
                    </div>
                    <button id="editTeamBtn" class="btn">Edit Team Details</button>
                </div>
            `;
            
            // Load team details
            loadTeamDetails();
            document.getElementById('editTeamBtn').addEventListener('click', showEditTeamForm);
            break;
            
        case 'announcements':
            content.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <h3>Announcements</h3>
                    </div>
                    <div id="announcementsList">
                        <p>Loading announcements...</p>
                    </div>
                </div>
            `;
            loadAnnouncements();
            break;
            
        case 'resources':
            content.innerHTML = `
                <div class="card">
                    <div class="card-header">
                        <h3>Resources</h3>
                    </div>
                    <div id="resourcesList">
                        <p>Loading resources...</p>
                    </div>
                </div>
            `;
            loadResources();
            break;
    }
}

async function loadTeamDetails() {
    // In a real app, you would fetch from Supabase
    const teamDetails = document.getElementById('teamDetails');
    teamDetails.innerHTML = `
        <div class="form-group">
            <label><strong>Team Name:</strong></label>
            <p>Innovators Team</p>
        </div>
        <div class="form-group">
            <label><strong>Leader Name:</strong></label>
            <p>John Doe</p>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label><strong>Stream:</strong></label>
                <p>Computer Science</p>
            </div>
            <div class="form-group">
                <label><strong>Semester:</strong></label>
                <p>4</p>
            </div>
        </div>
        <div class="form-group">
            <label><strong>Category:</strong></label>
            <p>GM</p>
        </div>
        <div class="form-group">
            <label><strong>Team Members:</strong></label>
            <ul>
                <li>Jane Smith (jane@example.com)</li>
                <li>Bob Johnson (bob@example.com)</li>
            </ul>
        </div>
    `;
}

function showEditTeamForm() {
    const teamDetails = document.getElementById('teamDetails');
    teamDetails.innerHTML = `
        <form id="editTeamForm" class="team-form">
            <div class="form-group">
                <label for="teamName">Team Name</label>
                <input type="text" id="teamName" value="Innovators Team" required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="leaderName">Leader Name</label>
                    <input type="text" id="leaderName" value="John Doe" required>
                </div>
                <div class="form-group">
                    <label for="stream">Stream</label>
                    <input type="text" id="stream" value="Computer Science" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="semester">Semester</label>
                    <input type="text" id="semester" value="4" required>
                </div>
                <div class="form-group">
                    <label for="category">Category</label>
                    <select id="category" required>
                        <option value="GM" selected>GM</option>
                        <option value="SC">SC</option>
                        <option value="ST">ST</option>
                        <option value="OBC">OBC</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>Team Members</label>
                <div id="membersContainer">
                    <div class="member-row">
                        <div class="form-group">
                            <input type="text" placeholder="Member Name" class="member-name" value="Jane Smith">
                        </div>
                        <div class="form-group">
                            <input type="email" placeholder="Member Email" class="member-email" value="jane@example.com">
                        </div>
                    </div>
                    <div class="member-row">
                        <div class="form-group">
                            <input type="text" placeholder="Member Name" class="member-name" value="Bob Johnson">
                        </div>
                        <div class="form-group">
                            <input type="email" placeholder="Member Email" class="member-email" value="bob@example.com">
                        </div>
                    </div>
                </div>
                <button type="button" id="addMember" class="btn btn-secondary">Add Member</button>
            </div>
            <button type="submit" class="btn btn-success">Save Changes</button>
            <button type="button" id="cancelEdit" class="btn btn-secondary">Cancel</button>
        </form>
    `;
    
    document.getElementById('addMember').addEventListener('click', addMemberField);
    document.getElementById('editTeamForm').addEventListener('submit', saveTeamChanges);
    document.getElementById('cancelEdit').addEventListener('click', loadTeamDetails);
}

function addMemberField() {
    const container = document.getElementById('membersContainer');
    const memberRow = document.createElement('div');
    memberRow.className = 'member-row';
    memberRow.innerHTML = `
        <div class="form-group">
            <input type="text" placeholder="Member Name" class="member-name">
        </div>
        <div class="form-group">
            <input type="email" placeholder="Member Email" class="member-email">
        </div>
        <button type="button" class="remove-member">Remove</button>
    `;
    container.appendChild(memberRow);
    
    // Add event listener to the remove button
    memberRow.querySelector('.remove-member').addEventListener('click', function() {
        container.removeChild(memberRow);
    });
}

async function saveTeamChanges(e) {
    e.preventDefault();
    
    // Get form data
    const teamName = document.getElementById('teamName').value;
    const leaderName = document.getElementById('leaderName').value;
    const stream = document.getElementById('stream').value;
    const semester = document.getElementById('semester').value;
    const category = document.getElementById('category').value;
    
    // Get team members
    const memberRows = document.querySelectorAll('.member-row');
    const members = [];
    memberRows.forEach(row => {
        const name = row.querySelector('.member-name').value;
        const email = row.querySelector('.member-email').value;
        if (name && email) {
            members.push({ name, email });
        }
    });
    
    // In a real app, you would save this to Supabase
    console.log({
        teamName,
        leaderName,
        stream,
        semester,
        category,
        members
    });
    
    alert('Team details updated successfully!');
    loadTeamDetails();
}

async function loadAnnouncements() {
    // In a real app, you would fetch from Supabase
    const announcementsList = document.getElementById('announcementsList');
    announcementsList.innerHTML = `
        <div class="list-item">
            <h4>Welcome to the Hackathon!</h4>
            <p>We're excited to have you participate in this year's hackathon. Please make sure to complete your team registration.</p>
            <small>Posted on: September 15, 2025</small>
        </div>
        <div class="list-item">
            <h4>Important Dates</h4>
            <p>Registration closes on October 1st. The hackathon begins on October 15th.</p>
            <small>Posted on: September 10, 2025</small>
        </div>
        <div class="list-item">
            <h4>Submission Guidelines</h4>
            <p>All projects must be submitted by October 20th at 11:59 PM. Late submissions will not be accepted.</p>
            <small>Posted on: September 5, 2025</small>
        </div>
    `;
}

async function loadResources() {
    // In a real app, you would fetch from Supabase
    const resourcesList = document.getElementById('resourcesList');
    resourcesList.innerHTML = `
        <div class="list-item">
            <h4>Hackathon Guidelines</h4>
            <p><a href="https://example.com/guidelines" class="resource-link" target="_blank">Download Guidelines Document</a></p>
        </div>
        <div class="list-item">
            <h4>API Documentation</h4>
            <p><a href="https://api.example.com/docs" class="resource-link" target="_blank">Access API Documentation</a></p>
        </div>
        <div class="list-item">
            <h4>Code of Conduct</h4>
            <p><a href="https://example.com/conduct" class="resource-link" target="_blank">Read Code of Conduct</a></p>
        </div>
    `;
}

async function handleLogout() {
    await supabase.auth.signOut();
    window.location.href = 'index.html';
}