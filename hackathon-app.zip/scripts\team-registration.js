// Supabase configuration
const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';

// Initialize Supabase
const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// DOM Elements
const teamForm = document.getElementById('teamRegistrationForm');
const addMemberBtn = document.getElementById('addMember');

// Add event listeners
document.addEventListener('DOMContentLoaded', async () => {
    // Check if user is logged in
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
        // Redirect to login if not authenticated
        window.location.href = 'index.html';
        return;
    }
    
    // Pre-fill leader name with user's email
    document.getElementById('leaderName').value = user.email;
    
    // Add event listeners
    teamForm.addEventListener('submit', handleTeamRegistration);
    addMemberBtn.addEventListener('click', addMemberField);
});

function addMemberField() {
    const container = document.getElementById('membersContainer');
    const memberRow = document.createElement('div');
    memberRow.className = 'member-row';
    memberRow.innerHTML = `
        <div class="form-group">
            <input type="text" placeholder="Member Name" class="member-name">
        </div>
        <div class="form-group">
            <input type="email" placeholder="Member Email" class="member-email">
        </div>
        <button type="button" class="remove-member">Remove</button>
    `;
    container.appendChild(memberRow);
    
    // Add event listener to the remove button
    memberRow.querySelector('.remove-member').addEventListener('click', function() {
        container.removeChild(memberRow);
    });
}

async function handleTeamRegistration(e) {
    e.preventDefault();
    
    // Get form data
    const teamName = document.getElementById('teamName').value;
    const leaderName = document.getElementById('leaderName').value;
    const stream = document.getElementById('stream').value;
    const semester = document.getElementById('semester').value;
    const category = document.getElementById('category').value;
    
    // Get team members
    const memberRows = document.querySelectorAll('.member-row');
    const members = [];
    memberRows.forEach(row => {
        const name = row.querySelector('.member-name').value;
        const email = row.querySelector('.member-email').value;
        if (name && email) {
            members.push({ name, email });
        }
    });
    
    // Save to Supabase (in a real implementation)
    try {
        // This is where you would save to your Supabase database
        console.log('Team Registration Data:', {
            teamName,
            leaderName,
            stream,
            semester,
            category,
            members
        });
        
        // For demo purposes, we'll just show an alert
        alert('Team registered successfully! Redirecting to dashboard...');
        window.location.href = 'index.html';
    } catch (error) {
        console.error('Error registering team:', error);
        alert('Error registering team. Please try again.');
    }
}